<?php
session_start();

$_SESSION['Hoehe'] = $_POST['hoehe'];
$_SESSION['Grundplatte'] = $_POST['grundplatte'];
$_SESSION['Belag'] = $_POST['belag'];
$_SESSION['Zubehoer'] = (isset($_POST['zubehoer']) ? "1" : "0");
$_SESSION['Befestigungshuelsen'] = (isset($_POST['bhuelsen']) ? "1" : "0");
$_SESSION['Breite'] = $_POST['breite'];
$_SESSION['Laenge'] = $_POST['laenge'];
$_SESSION['Kabeltyp'] = $_POST['kabel'];
$_SESSION['Kabelausgang'] = $_POST['kabelausgang'];
$_SESSION['Kabelposition'] = $_POST['kabelposition'];
$_SESSION['invertiert'] = (isset($_POST['invert']) ? "1" : "0");
$_SESSION['Pro'] = (isset($_POST['pro']) ? "1" : "0");
$_SESSION['Farbe'] = $_POST['farbe'];
$_SESSION['Preis'] = $_POST['preis_value'];
$_SESSION['Grundpreis'] = $_POST['Grundpreis'];
$_SESSION['PreisProQM'] = $_POST['PreisProQM'];

header("Location: summary.php");
?>