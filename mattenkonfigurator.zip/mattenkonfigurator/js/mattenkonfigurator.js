// Enable Tooltips
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

// Konstanten der HTML Elemente
const select_kabelpos = document.getElementById('kabelposition');
const lbl_kabelpos = document.getElementById('lbl_kabelposition');
const btn_gpU = document.getElementById('GP_U');
const btn_gpT = document.getElementById('GP_T');
const btn_gpF = document.getElementById('GP_F');
const btn_belag_np = document.getElementById('BLG_NP');
const btn_belag_arb = document.getElementById('BLG_ARB');
const btn_belag_tbv = document.getElementById('BLG_TBV');
const btn_belag_sa = document.getElementById("BLG_SA");
const btn_belag_ohne = document.getElementById('BLG_OHNE');
const btn_h10 = document.getElementById("hoehe_10");
const btn_h12 = document.getElementById("hoehe_12");
const btn_h14 = document.getElementById("hoehe_14");
const btn_frb_schwarz = document.getElementById('FRB_SCH');
const btn_frb_grau = document.getElementById('FRB_GR');
const btn_frb_gelb = document.getElementById('FRB_GE');
const lbl_frb = document.getElementById('lbl_FRB');
const btn_kabelausgang_kurz = document.getElementById('KBLA_K');
const btn_kabelausgang_lang = document.getElementById('KBLA_L');
const btn_kabelausgang_dia = document.getElementById('KBLA_D');
const lbl_kabelausgang = document.getElementById('lbl_KBLA');
const btn_zubehoer = document.getElementById('zubehoer');
const lbl_zubehoer = document.getElementById('lbl_zubehoer');
const txt_laenge = document.getElementById('laenge');
const txt_breite = document.getElementById('breite');
const btn_bhuelsen = document.getElementById('bhuelsen');
const lbl_bhuelsen = document.getElementById('lbl_bhuelsen');
const validation_feedback_breite = document.getElementById('feedback_breite');
const hinweis = document.getElementById('error');
const select_kabel = document.getElementById('kabel');
const btn_pro = document.getElementById('pro');
const lbl_schutzklasse_pro = document.getElementById('lbl_pro');
const btn_invertiert = document.getElementById('invert');
const lbl_invertiert = document.getElementById('lbl_invert');
const card_typenschluessel = document.getElementById('typenschluessel');
const card_laenge_1 = document.getElementById('size-length');
const card_breite_1 = document.getElementById('size-width');
const card_laenge_2 = document.getElementById('size-length-2');
const card_breite_2 = document.getElementById('size-width-2');

const img_maßlinien_anguss = document.getElementById('img-Measure-Anguss');
const img_maßlinien_rs14 = document.getElementById('img-Measure-RS14');
const img_blg_np_schwarz = document.getElementById('img-BLG_NP_SCHWARZ');
const img_blg_np_grau = document.getElementById('img-BLG_NP_GRAU');
const img_blg_np_gelb = document.getElementById('img-BLG_NP_GELB');
const img_blg_sa_schwarz = document.getElementById('img-BLG_SA_SCHWARZ');
const img_blg_sa_grau = document.getElementById('img-BLG_SA_GRAU');
const img_blg_sa_gelb = document.getElementById('img-BLG_SA_GELB');
const img_blg_arb = document.getElementById('img-BLG_ARB');
const img_blg_tbv = document.getElementById('img-BLG_TBV');
const img_blg_ohne = document.getElementById('img-GP_F_BLG_OHNE');
const img_rampenschiene = document.getElementById('img-Zubehoer');
const img_bhuelsen = document.getElementById('img-Befestigungshuelsen');
const img_anguss_schwarz = document.getElementById('img-Anguss_SCHWARZ');
const img_anguss_grau = document.getElementById('img-Anguss_GRAU');
const img_anguss_gelb = document.getElementById('img-Anguss_GELB');

const img_kbl_1_eck_kurz = document.getElementById('img-Kabel-1-ECK-kurz');
const img_kbl_1_eck_lang = document.getElementById('img-Kabel-1-ECK-lang');
const img_kbl_1_mid_kurz = document.getElementById('img-Kabel-1-MID-kurz');
const img_kbl_1_mid_lang = document.getElementById('img-Kabel-1-MID-lang');
const img_kbl_2_eck_kurz = document.getElementById('img-Kabel-2-ECK-kurz');
const img_kbl_2_eck_lang = document.getElementById('img-Kabel-2-ECK-lang');
const img_kbl_2_mid_kurz = document.getElementById('img-Kabel-2-MID-kurz');
const img_kbl_2_mid_lang = document.getElementById('img-Kabel-2-MID-lang');
const img_kbl_2_dia_1 = document.getElementById('img-Kabel-2-DIA-1');
const img_kbl_2_dia_2 = document.getElementById('img-Kabel-2-DIA-2');
 
 
// GETTER FUNKTIONEN
// Getter Grundplatte
function getGrundplatte(){
    let grundplatte_U = btn_gpU.checked;
    let grundplatte_T = btn_gpT.checked;
    let grundplatte_F = btn_gpF.checked;

    if(grundplatte_U){
        return "U";
    }
    else if(grundplatte_T){
        return "T";
    }
    else if(grundplatte_F){
        return "F";
    }
    return "";
}

// Getter Belag
function getBelag(){
    let belag_np = btn_belag_np.checked;
    let belag_arb = btn_belag_arb.checked;
    let belag_tbv = btn_belag_tbv.checked;
    let belag_sa = btn_belag_sa.checked;
    let belag_ohne = btn_belag_ohne.checked;

    if(belag_np){
        return "NP";
    }
    else if(belag_arb){
        return "ARB";
    }
    else if(belag_tbv){
        return "TBV";
    }
    else if(belag_sa){
        return "SA";
    }
    else if(belag_ohne){
        return "OHNE";
    }
    return "";
}

// Getter Hoehe
function getHoehe(){
    let hoehe_14 = btn_h14.checked;
    let hoehe_12 = btn_h12.checked;
    let hoehe_10 = btn_h10.checked;

    if(hoehe_14){
        return 14;
    }
    else if(hoehe_12){
        return 12;
    }
    else if(hoehe_10){
        return 10;
    }
}

// Getter Farbe
function getFarbe(){
    let schwarz = btn_frb_schwarz.checked;
    let grau = btn_frb_grau.checked;
    let gelb = btn_frb_gelb.checked;

    if(schwarz){
        return "Schwarz";
    }
    else if(grau){
        return "Grau";
    }
    else if(gelb){
        return "Gelb";
    }
    return "";
}

// Getter Kabelausgang
function getKabelausgang(){
    let kurzseite = btn_kabelausgang_kurz.checked;
    let langseite = btn_kabelausgang_lang.checked;
    let diagonal = btn_kabelausgang_dia.checked;
    
    if(kurzseite){
        return "kurz";
    }
    else if(langseite){
        return "lang";
    }
    else if(diagonal){
        return "diagonal";
    }
    return "";
}

// EVENTS FÜR REGELN, KOMPABILITÄT
// Aktiviert bzw. deaktiviert die Zubehörauswahl
function showZubehoer(){
    let grundplatte = getGrundplatte();

    if(grundplatte == "T"){
        btn_zubehoer.checked = false;
        lbl_zubehoer.style.opacity = 0.3;
        btn_zubehoer.disabled = true;
        btn_zubehoer.style.display = 'none';
    }
    else{
        lbl_zubehoer.style.opacity = 1;
        btn_zubehoer.disabled = false;
        btn_zubehoer.style.display = '';
    }
}

// Zubehör wird als Default auf AN geschaltet, wenn Belag ARB, TBV oder OHNE und Grundplatte nicht T
function setDefaultZubehoer(){
    let belag = getBelag();
    let grundplatte = getGrundplatte();

    if(grundplatte != "T"){
        if(belag == "ARB" || belag == "TBV" || belag == "OHNE"){
            btn_zubehoer.checked = true;
        }
        else{
            btn_zubehoer.checked = false;
        }
    }
}

// Zeigt Befestigungshülsen wenn größer 500x500 und Belag Sand oder Noppe
function showBHuelsen(){
    let belag = getBelag();
    let laenge = parseFloat(txt_laenge.value);
    let breite = parseFloat(txt_breite.value);

    if(breite >= 500 && laenge >= 500){
        if(belag == "NP" || belag == "SA"){
            btn_bhuelsen.disabled = false;
            btn_bhuelsen.style.opacity = 1;
            lbl_bhuelsen.style.opacity = 1;
        }
        else{
            btn_bhuelsen.disabled = true;
            btn_bhuelsen.checked = false;
            btn_bhuelsen.style.opacity = 0.3;
            lbl_bhuelsen.style.opacity = 0.3;
        }
    }
    else{
        btn_bhuelsen.disabled = true;
        btn_bhuelsen.checked = false;
        btn_bhuelsen.style.opacity = 0.3;
        lbl_bhuelsen.style.opacity = 0.3;
    }
}

// Regel zur Grundplattenauswahl
function rule_HoeheGrundplatte(){
    let hoehe = getHoehe();
    if(hoehe == 10){
        btn_gpU.disabled = true;
        btn_gpT.disabled = true;
        btn_gpF.disabled = false;
        btn_gpF.checked = true;
    }
    else if(hoehe == 12){
        btn_gpU.disabled = false;
        btn_gpT.disabled = false;
        btn_gpF.disabled = true;
        btn_gpF.checked = false;
        btn_gpU.checked = true;
    }
    else if(hoehe == 14){
        btn_gpU.disabled = false;
        btn_gpT.disabled = false;
        btn_gpF.disabled = false;
        btn_gpU.checked = true;
    }
}

// Regel zur Belagauswahl
function rule_GrundplatteHoeheBelag(){
    let grundplatte = getGrundplatte();
    let hoehe = getHoehe();

    if(grundplatte == "F" && hoehe == 10){
        btn_belag_ohne.disabled = false;

        btn_belag_arb.disabled = true;
        btn_belag_tbv.disabled = true;
        btn_belag_np.disabled = true;
        btn_belag_sa.disabled = true;

        btn_belag_ohne.checked = true;
    }
    else if(grundplatte == "F"){
        btn_belag_arb.disabled = false;
        btn_belag_tbv.disabled = false;

        btn_belag_ohne.disabled = true;
        btn_belag_np.disabled = true;
        btn_belag_sa.disabled = true;

        btn_belag_arb.checked = true;
        btn_belag_ohne.checked = false;
    }
    else if(hoehe == 12 && grundplatte == "U" || hoehe == 12 && grundplatte == "T"){
        btn_belag_sa.disabled = false;

        btn_belag_ohne.disabled = true;
        btn_belag_arb.disabled = true;
        btn_belag_tbv.disabled = true;
        btn_belag_np.disabled = true;

        btn_belag_sa.checked = true;
    }
    else if(hoehe == 14 && grundplatte != "F"){
        btn_belag_np.disabled = false;
        btn_belag_sa.disabled = false;

        btn_belag_ohne.disabled = true;
        btn_belag_arb.disabled = true;
        btn_belag_tbv.disabled = true;

        btn_belag_ohne.checked = false;
        btn_belag_arb.checked = false;
        btn_belag_tbv.checked = false;
    }
}

// Schreibt die berechneten Größen an die Maßlinien
function fillSizeCard(){
    let length = txt_laenge.value;
    let width = txt_breite.value;

    let angespritzteRS = btn_gpT.checked;
    let zubehoer = btn_zubehoer.checked;

    if(length == 0 && width == 0){
        card_laenge_1.innerHTML = '';
        card_breite_1.innerHTML = '';
        card_laenge_2.innerHTML = '';
        card_breite_2.innerHTML = '';
    }
    else{
        let textLength = length + "mm";
        let textWidth = width + "mm";

        if(angespritzteRS){
            let textLength2 = parseFloat(length) + 60 + "mm";
            let textWidth2 = parseFloat(width) + 60 + "mm";
            card_laenge_2.innerHTML = textLength2;
            card_breite_2.innerHTML = textWidth2;
        }
        else if(zubehoer){
            let textLength2 = parseFloat(length) + 124 + "mm";
            let textWidth2 = parseFloat(width) + 124 + "mm";
            card_laenge_2.innerHTML = textLength2;
            card_breite_2.innerHTML = textWidth2;
        }
        else{
            card_laenge_2.innerHTML = '';
            card_breite_2.innerHTML = '';
        }

        card_laenge_1.innerHTML = textLength;
        card_breite_1.innerHTML = textWidth;
    }
}

// Macht die Länge immer zu dem größeren Maß nach Eingabe
function makeLengthGreaterMeasure(){
    let laenge = parseFloat(txt_laenge.value);
    let breite = parseFloat(txt_breite.value);

    if(breite != 0 && laenge != 0 && breite > laenge){
        txt_laenge.value = breite;
        txt_breite.value = laenge;
    }
    fillSizeCard();
}

// Prüft das Längenverhältnis, wenn dies größer als 1 : 5, zeige einen Hinweis
function checkLaengenverhaeltnis(){
    let laenge = parseFloat(txt_laenge.value);
    let breite = parseFloat(txt_breite.value);

    if(laenge / breite >= 5){
        hinweis.innerHTML = 'Das Längenverhältnis ist größer als 1 : 5. Es wird empfohlen die Matte zu teilen.';
    }
    else{
        hinweis.innerHTML = '';
    }
}

// Wenn Länge >= 1350, dann Breite nur <= 1350
function rule_Laengenverhaeltnis_1350(){
    let laenge = parseFloat(txt_laenge.value);
    let breite = parseFloat(txt_breite.value);

    if(laenge >= 1350 && breite > 1350){
        validation_feedback_breite.innerHTML = "Ab einer Länge von 1350mm, darf die Breite nur noch maximal 1350mm sein";
        txt_breite.setAttribute('max', 1350);
    }
    else{
        validation_feedback_breite.innerHTML = "Bitte geben Sie eine valide Breite ein (min: 150mm, max: 2000mm)";
        txt_breite.setAttribute('max', 2000);
    }
}

// Führt einmal alle Regeln aus
function executeAllRules(){
    rule_HoeheGrundplatte();
    rule_GrundplatteHoeheBelag();
    rule_Laengenverhaeltnis_1350();
    checkLaengenverhaeltnis();
    setDefaultZubehoer();
    showFarbe();
    showKabelProps();
    showZubehoer();
    showBHuelsen();
    showMeasureLines();
}

// Erstellt den Typenschlüssel (Anzeige über dem Bild)
function buildTypenschluessel(){
    let hoehe = getHoehe();
    let schaltzonen = "1";
    let grundplatte = getGrundplatte();
    let kabel = select_kabel.value;
    let belag = getBelag();
    
    let pro = btn_pro.checked;

    if(hoehe != "" && schaltzonen != "" && grundplatte != "" && kabel != "" && belag != ""){
        if(belag == "OHNE"){
            belag = '';
        }
        if(pro){
            pro = "- PRO";
        }
        else{
            pro = "";
        }

        let typenschluessel = hoehe + "-" + schaltzonen + grundplatte + kabel + "-" + belag + pro;
        typenschluessel = typenschluessel.replace("--", "-");
        if(typenschluessel.charAt(typenschluessel.length - 1) == "-"){
            typenschluessel = typenschluessel.substring(0, typenschluessel.length - 1);
        }

        card_typenschluessel.innerHTML = typenschluessel;
    }
    else{
        card_typenschluessel.innerHTML = '';
    }
}

// Zeigt die Maßlinien an, je nach Grundplatte u. Zubehörauswahl
function showMeasureLines(){
    let grundplatte = getGrundplatte();
    let zubehoer = btn_zubehoer.checked;

    if(grundplatte == "T"){
        img_maßlinien_anguss.style.display = '';
        img_maßlinien_rs14.style.display = 'none';
    }
    else if(zubehoer){
        img_maßlinien_anguss.style.display = 'none';
        img_maßlinien_rs14.style.display = '';
    }
    else{
        img_maßlinien_anguss.style.display = 'none';
        img_maßlinien_rs14.style.display = 'none';
    }
}

// Generiert die passenden Einstellungen zum gewählten Kabel
function showKabelProps(){
    let kabel = select_kabel.value;
    let kabelausgang = getKabelausgang();

    if(kabel == ""){
        btn_kabelausgang_kurz.disabled = true;
        btn_kabelausgang_lang.disabled = true;
        btn_kabelausgang_dia.disabled = true;
        lbl_kabelausgang.style.opacity = 0.3;

        select_kabelpos.disabled = true;
        lbl_kabelpos.style.opacity = 0.3;

        btn_pro.disabled = true;
        lbl_schutzklasse_pro.style.opacity = 0.3;
    }
    else{
        if(kabel == "2" || kabel == "3" || kabel == "4.0" || kabel == "4.2" || kabel == "4.3" || kabel == "4.4" || kabel == "7.0" || kabel == "7.2" || kabel == "7.3"){
            btn_kabelausgang_dia.disabled = false;

            if(kabel != "2"){
                btn_invertiert.disabled = false;
                lbl_invertiert.style.opacity = 1;
            }

            if(kabelausgang == "diagonal"){
                removeAll(select_kabelpos);
                let option1 = new Option("Diagonal 1", "Diagonal 1");
                let option2 = new Option("Diagonal 2", "Diagonal 2");
                select_kabelpos.add(option1, undefined);
                select_kabelpos.add(option2, undefined);
            }
            else{
                // Optionsliste erstellen
                removeAll(select_kabelpos);
                let option1 = new Option("Mittig", "Mittig");
                let option2 = new Option("Ecke", "Ecke");
                select_kabelpos.add(option1, undefined);
                select_kabelpos.add(option2, undefined);
            }
        }
        else{
            btn_kabelausgang_dia.disabled = true;
            btn_kabelausgang_dia.checked = false;
            btn_invertiert.disabled = true;
            btn_invertiert.checked = false;
            lbl_invertiert.style.opacity = 0.3;

            if(kabel == "0" || kabel == "1" || kabel == "5"){
                // Optionsliste erstellen
                removeAll(select_kabelpos);
                let option1 = new Option("Mittig", "Mittig");
                let option2 = new Option("Ecke", "Ecke");
                select_kabelpos.add(option1, undefined);
                select_kabelpos.add(option2, undefined);
            }
            else if(kabel == "6"){
                removeAll(select_kabelpos);
                let option1 = new Option("Mittig", "Mittig");
                select_kabelpos.add(option1, undefined);
            }
        }
        btn_kabelausgang_kurz.disabled = false;
        btn_kabelausgang_lang.disabled = false;
        lbl_kabelausgang.style.opacity = 1;

        select_kabelpos.disabled = false;
        lbl_kabelpos.style.opacity = 1;

        btn_pro.disabled = false;
        lbl_schutzklasse_pro.style.opacity = 1;
    }
}

// Prüft ob Farbauswahl möglich oder nicht (nicht möglich bei: ohne Belag, F, 10)
function showFarbe(){
    let hoehe = getHoehe();
    let belag = getBelag();
    let grundplatte = getGrundplatte();

    if(hoehe == 10 && belag == 'OHNE' && grundplatte == "F" || belag == "ARB" || belag == "TBV"){
        btn_frb_schwarz.disabled = true;
        btn_frb_grau.disabled = true;
        btn_frb_gelb.disabled = true;
        lbl_frb.style.opacity = 0.3;
    }
    else{
        btn_frb_schwarz.disabled = false;
        btn_frb_grau.disabled = false;
        btn_frb_gelb.disabled = false;
        lbl_frb.style.opacity = 1;
    }
}

// FUNKTIONEN FÜR IMAGES / BILDER
// Kein Bild anzeigen
function clearAll(){
    let images = document.getElementsByClassName('img-pos');

    for(let i = 0; i < images.length; i++){
        images[i].style.display = 'none';
    }
}

// Zeigt Bild für den gewählten Belag an in der gewählten Farbe
function img_Belag(){
    let belag = getBelag();
    let farbe = getFarbe();
    switch(belag){
        case "NP":
            switch(farbe){
                case "Schwarz":
                    img_blg_np_schwarz.style.display = '';
                    break;
                case "Grau":
                    img_blg_np_grau.style.display = '';
                    break;
                case "Gelb":
                    img_blg_np_gelb.style.display = '';
                    break;
            }
            break;
        case "SA":
            switch(farbe){
                case "Schwarz":
                    img_blg_sa_schwarz.style.display = '';
                    break;
                case "Grau":
                    img_blg_sa_grau.style.display = '';
                    break;
                case "Gelb":
                    img_blg_sa_gelb.style.display = '';
                    break;
            }
            break;
        case "ARB":
            img_blg_arb.style.display = '';
            break;
        case "TBV":
            img_blg_tbv.style.display = '';
            break;
        case "OHNE":
            img_blg_ohne.style.display = '';
            break
    }
}

// Zeigt Eckverbinder & Rampenschiene an, wenn Zubehör ausgewählt
function img_Zubehoer(){
    let zubehoer = btn_zubehoer.checked;
    
    if(zubehoer){
        img_rampenschiene.style.display = '';
    }
    else{
        img_rampenschiene.style.display = 'none';
    }
}

// Zeigt Befestigungshülsen an, wenn ausgewählt
function img_Befestigungshuelsen(){
    let befestigungshuelsen = btn_bhuelsen.checked;

    if(befestigungshuelsen){
        img_bhuelsen.style.display = '';
    }
    else{
        img_bhuelsen.style.display = 'none';
    }
}

// Zeigt die angegossene Rampenschiene in der gewählten Farbe an, wenn Grundplatte = T
function img_Angussrampenschiene(){
    let grundplatte = getGrundplatte();
    let farbe = getFarbe();
    if(grundplatte == "T"){
        switch(farbe){
            case "Schwarz":
                img_anguss_schwarz.style.display = '';
                break;
            case "Grau":
                img_anguss_grau.style.display = '';
                break;
            case "Gelb":
                img_anguss_gelb.style.display = '';
                break;
        }
    }
}

// Zeigt den Grundbelag F an, wenn Grundplatte = F und OHNE BELAG gewählt
function img_GP_F_BLG_OHNE(){
    let grundplatte = getGrundplatte();
    let belag = getBelag();

    if(grundplatte == 'F' && belag == 'OHNE'){
        img_blg_ohne.style.display = '';
    }
}

// Macht alle Kästen der Kabelausgänge unsichtbar
function clearAllKabelinfo(){
    let elements = document.getElementsByClassName('kabelinfo');
    for(let i = 0; i < elements.length; i++){
        elements[i].style.visibility = 'hidden';
    }

    let elements2 = document.getElementsByClassName('kabelinfo_span');
    for(let i = 0; i < elements.length; i++){
        elements2[i].style.visibility = 'hidden';
    }
}

// Macht den Kasten der Kabelausgänge sichtbar und setzt den Pfad der dazugehörigen Bilder, die beim Hover angezeigt werden
function showKabelinfo(hoverImageID, type, pos, inverted, kabeltyp){
    let elem = document.getElementsByClassName(hoverImageID);
    elem[0].style.visibility = "visible";

    if(kabeltyp != "3"){
        if(inverted){
            if(type == "male"){
                type = "female";
            }
            else if(type == "female"){
                type = "male";
            }
        }
    }
    else{
        if(inverted){
            if(type == "2Wire"){
                type = "Widerstand";
            }
            else if(type == "Widerstand"){
                type = "2Wire";
            }
        }
    }

    if(kabeltyp == "0" || kabeltyp == "1" || kabeltyp == "2" || kabeltyp == "3"){
        if(type == "2Wire"){
            document.getElementById(hoverImageID).innerHTML = "2Wire";
        }
        else if(type == "Widerstand"){
            document.getElementById(hoverImageID).innerHTML = "8.2k&#8486;";
        }
    }
    else if(kabeltyp == "4" || kabeltyp == "7" || kabeltyp == "5"){
        if(type == "male"){
            document.getElementById(hoverImageID).innerHTML = "M8/m";
        }
        else if(type == "female"){
            document.getElementById(hoverImageID).innerHTML = "M8/f";
        }
    }
    else if(kabeltyp == "6"){
        document.getElementById(hoverImageID).innerHTML = "4Wire";
    }

    switch(pos){
        case "OL":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageOL = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if (kabeltyp == "7"){
                    pathToImageOL = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageOL = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOL = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageOL = "images/Widerstand_2.png"; 
            }
            else if(type == "2Wire"){
                pathToImageOL = "images/2-Adrig_2.png";
            }
            break;
        case "OM1":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageOM1 = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOM1 = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageOM1 = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOM1 = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageOM1 = "images/Widerstand_2.png"; 
            }
            else if(type == "2Wire"){
                pathToImageOM1 = "images/2-Adrig_2.png"; 
            }
            else if(type == "4Wire"){
                pathToImageOM1 = "images/4-Adrig_2.png";
            }
            break;
        case "OM2":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageOM2 = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOM2 = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageOM2 = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOM2 = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageOM2 = "images/Widerstand_2.png";
            }
            else if(type == "2Wire"){
                pathToImageOM2 = "images/2-Adrig_2.png";
            }
            break;
        case "OR":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageOR = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOR = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageOR = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageOR = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageOR = "images/Widerstand_2.png";
            }
            else if(type == "2Wire"){
                pathToImageOR = "images/2-Adrig_2.png";
            }
            break;
        case "RM1":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageRM1 = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageRM1 = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageRM1 = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageRM1 = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageRM1 = "images/Widerstand_2.png";
            }
            else if(type == "2Wire"){
                pathToImageRM1 = "images/2-Adrig_2.png";
            }
            else if(type == "4Wire"){
                pathToImageRM1 = "images/4-Adrig_2.png";
            }
            break;
        case "RM2":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageRM2 = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageRM2 = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageRM2 = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageRM2 = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageRM2 = "images/Widerstand_2.png";
            }
            else if(type == "2Wire"){
                pathToImageRM2 = "images/2-Adrig_2.png";
            }
            break;
        case "RU":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageRU = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageRU = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageRU = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageRU = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageRU = "images/Widerstand_2.png";
            }
            else if(type == "2Wire"){
                pathToImageRU = "images/2-Adrig_2.png";
            }
            break;
        case "LU":
            if(type == "male"){
                if(kabeltyp == "4" || kabeltyp == "5"){
                    pathToImageLU = "images/M8-male, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageLU = "images/M8-male, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "female"){
                if(kabeltyp == "4"){
                    pathToImageLU = "images/M8-female, 2-adrig, 3-polig (4.0).png";
                }
                else if(kabeltyp == "7"){
                    pathToImageLU = "images/M8-female, 2-adrig, 4-polig (7.0).png";
                }
            }
            else if(type == "Widerstand"){
                pathToImageLU = "images/Widerstand_2.png";
            }
            else if(type == "2Wire"){
                pathToImageLU = "images/2-Adrig_2.png";
            }
            break;
            

    }
}

function img_Kabel(){
    clearAllKabelinfo();
    let kabel = select_kabel.value;
    let kabelausgang = getKabelausgang();
    let kabelposition = select_kabelpos.value;

    let inverted = btn_invertiert.checked;

    switch(kabel){
        case "0":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_1_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "2Wire", "OL", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_1_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "2Wire", "OM1", inverted, kabel);
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_1_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_1_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "2Wire", "RM", inverted, kabel);
                            break;
                    }
                    break;
            }
            break;
        case "1":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_1_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "2Wire", "OL", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_1_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "2Wire", "OM1", inverted, kabel);
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_1_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_1_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "2Wire", "RM1", inverted, kabel);
                            break;
                    }
                    break;
            }
            break;
        case "2":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "2Wire", "OL", inverted, kabel);
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_2_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "2Wire", "OM1", inverted, kabel);
                            showKabelinfo("text-hover-image-OM-2", "2Wire", "OM2", inverted, kabel);
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            showKabelinfo("text-hover-image-RU", "2Wire", "RU", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_2_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "2Wire", "RM1", inverted, kabel);
                            showKabelinfo("text-hover-image-RM-2", "2Wire", "RM2", inverted, kabel);
                            break;
                    }
                    break;
                case "diagonal":
                    switch(kabelposition){
                        case "Diagonal 1":
                            img_kbl_2_dia_1.style.display = '';
                            showKabelinfo("text-hover-image-OL", "2Wire", "OL", inverted, kabel);
                            showKabelinfo("text-hover-image-RU", "2Wire", "RU", inverted, kabel);
                            break;
                        case "Diagonal 2":
                            img_kbl_2_dia_2.style.display = '';
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            showKabelinfo("text-hover-image-LU", "2Wire", "LU", inverted, kabel);
                            break;
                    }
                    break;
            }
            break;
        case "3":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "2Wire", "OL", inverted, kabel);
                            showKabelinfo("text-hover-image-OR", "Widerstand", "OR", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_2_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "2Wire", "OM1", inverted, kabel);
                            showKabelinfo("text-hover-image-OM-2", "Widerstand", "OM2", inverted, kabel);
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            showKabelinfo("text-hover-image-RU", "Widerstand", "RU", inverted, kabel);
                            break;
                        case "Mittig":
                            img_kbl_2_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "2Wire", "RM1", inverted, kabel);
                            showKabelinfo("text-hover-image-RM-2", "Widerstand", "RM2", inverted, kabel);
                            break;
                    }
                    break;
                case "diagonal":
                    switch(kabelposition){
                        case "Diagonal 1":
                            img_kbl_2_dia_1.style.display = '';
                            showKabelinfo("text-hover-image-OL", "2Wire", "OL", inverted, kabel);
                            showKabelinfo("text-hover-image-RU", "Widerstand", "RU", inverted, kabel);
                            break;
                        case "Diagonal 2":
                            img_kbl_2_dia_2.style.display = '';
                            showKabelinfo("text-hover-image-OR", "2Wire", "OR", inverted, kabel);
                            showKabelinfo("text-hover-image-LU", "Widerstand", "LU", inverted, kabel);
                            break;
                    }
                    break;
            }
            break;
        case "4.0":
        case "4.2":
        case "4.3":
        case "4.4":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "male", "OL", inverted, "4");
                            showKabelinfo("text-hover-image-OR", "female", "OR", inverted, "4");
                            break;
                        case "Mittig":
                            img_kbl_2_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "male", "OM1", inverted, "4");
                            showKabelinfo("text-hover-image-OM-2", "female", "OM2", inverted, "4");
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "male", "OR", inverted, "4");
                            showKabelinfo("text-hover-image-RU", "female", "RU", inverted, "4");
                            break;
                        case "Mittig":
                            img_kbl_2_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "male", "RM1", inverted, "4");
                            showKabelinfo("text-hover-image-RM-2", "female", "RM2", inverted, "4");
                            break;
                    }
                    break;
                case "diagonal":
                    switch(kabelposition){
                        case "Diagonal 1":
                            img_kbl_2_dia_1.style.display = '';
                            showKabelinfo("text-hover-image-OL", "male", "OL", inverted, "4");
                            showKabelinfo("text-hover-image-RU", "female", "RU", inverted, "4");
                            break;
                        case "Diagonal 2":
                            img_kbl_2_dia_2.style.display = '';
                            showKabelinfo("text-hover-image-OR", "male", "OR", inverted, "4");
                            showKabelinfo("text-hover-image-LU", "female", "LU", inverted, "4");
                            break;
                    }
                    break;
            }
            break;
        case "5":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_1_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "male", "OL", inverted, "5");
                            break;
                        case "Mittig":
                            img_kbl_1_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "male", "OM1", inverted, "5");
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_1_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "male", "OR", inverted, "5");
                            break;
                        case "Mittig":
                            img_kbl_1_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "male", "RM1", inverted, "5");
                            break;
                    }
                    break;
            }
            break;
        case "6":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Mittig":
                            img_kbl_1_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "4Wire", "OM1", inverted, "6");
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Mittig":
                            img_kbl_1_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "4Wire", "RM1", inverted, "6");
                            break;
                    }
                    break;
            }
            break;
        case "7.0":
        case "7.2":
        case "7.3":
            switch(kabelausgang){
                case "kurz":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OL", "male", "OL", inverted, "7");
                            showKabelinfo("text-hover-image-OR", "female", "OR", inverted, "7");
                            break;
                        case "Mittig":
                            img_kbl_2_mid_kurz.style.display = '';
                            showKabelinfo("text-hover-image-OM-1", "male", "OM1", inverted, "7");
                            showKabelinfo("text-hover-image-OM-2", "female", "OM2", inverted, "7");
                            break;
                    }
                    break;
                case "lang":
                    switch(kabelposition){
                        case "Ecke":
                            img_kbl_2_eck_lang.style.display = '';
                            showKabelinfo("text-hover-image-OR", "male", "OR", inverted, "7");
                            showKabelinfo("text-hover-image-RU", "female", "RU", inverted, "7");
                            break;
                        case "Mittig":
                            img_kbl_2_mid_lang.style.display = '';
                            showKabelinfo("text-hover-image-RM-1", "male", "RM1", inverted, "7");
                            showKabelinfo("text-hover-image-RM-2", "female", "RM2", inverted, "7");
                            break;
                    }
                    break;
                case "diagonal":
                    switch(kabelposition){
                        case "Diagonal 1":
                            img_kbl_2_dia_1.style.display = '';
                            showKabelinfo("text-hover-image-OL", "male", "OL", inverted, "7");
                            showKabelinfo("text-hover-image-RU", "female", "RU", inverted, "7");
                            break;
                        case "Diagonal 2":
                            img_kbl_2_dia_2.style.display = '';
                            showKabelinfo("text-hover-image-OR", "male", "OR", inverted, "7");
                            showKabelinfo("text-hover-image-LU", "female", "LU", inverted, "7");
                            break;
                    }
                    break;
            }
            break;

    }
}

// Cleart alle Bilder und lädt neu
function loadImages(){
    clearAll();
    showMeasureLines();
    img_Belag();
    img_Zubehoer();
    img_Befestigungshuelsen();
    img_Angussrampenschiene();
    img_Kabel();
}

// Lädt einmal alle Eingaben
// Triggers onload on body
function loadAll(){
    executeAllRules();
    loadImages();
    buildTypenschluessel();
    fillSizeCard();
}

// Wird bei jedem Event ausgeführt
function alwaysExecute(){
    loadImages();
    buildTypenschluessel();
    fillSizeCard();
    preisberechnung();
}

// EVENT LISTENER
// Grundplatten
// U
btn_gpU.addEventListener('change', function(){
    rule_GrundplatteHoeheBelag();
    showZubehoer();
    showBHuelsen();
    showFarbe();
    alwaysExecute();
})
// T
btn_gpT.addEventListener('change', function(){
    rule_GrundplatteHoeheBelag();
    showBHuelsen();
    showZubehoer();
    showFarbe();
    alwaysExecute();
})
// F 
btn_gpF.addEventListener('change', function(){
    rule_GrundplatteHoeheBelag();
    setDefaultZubehoer();
    showBHuelsen();
    showZubehoer();
    showFarbe();
    alwaysExecute();
})

// Belag
// NP
btn_belag_np.addEventListener('change', function(){
    setDefaultZubehoer();
    showBHuelsen();
    showFarbe();
    alwaysExecute();
})
// ARB
btn_belag_arb.addEventListener('change', function(){
    setDefaultZubehoer();
    showBHuelsen();
    showFarbe();
    alwaysExecute();
})
// TBV
btn_belag_tbv.addEventListener('change', function(){
    setDefaultZubehoer();
    showBHuelsen();
    showFarbe();
    alwaysExecute();
})
// SA 
btn_belag_sa.addEventListener('change', function(){
    setDefaultZubehoer();
    showBHuelsen();
    showFarbe();
    alwaysExecute();
})
// OHNE
btn_belag_ohne.addEventListener('change', function(){
    setDefaultZubehoer();
    showBHuelsen();
    showFarbe();
    alwaysExecute();
})

// Laenge & Breite
txt_laenge.addEventListener('change', function(){
    makeLengthGreaterMeasure();
    checkLaengenverhaeltnis();
    rule_Laengenverhaeltnis_1350();
    showBHuelsen();
    alwaysExecute();
});
txt_breite.addEventListener('change', function(){
    makeLengthGreaterMeasure();
    checkLaengenverhaeltnis();
    rule_Laengenverhaeltnis_1350();
    showBHuelsen();
    alwaysExecute();
});

txt_laenge.addEventListener('input', fillSizeCard);
txt_breite.addEventListener('input', fillSizeCard);

// Hoehe
btn_h14.addEventListener('change', function(){
    rule_HoeheGrundplatte();
    rule_GrundplatteHoeheBelag();
    showZubehoer();
    showFarbe();
    alwaysExecute();
});

btn_h12.addEventListener('change', function(){
    rule_HoeheGrundplatte();
    rule_GrundplatteHoeheBelag();
    showZubehoer();
    showFarbe();
    alwaysExecute();
});

btn_h10.addEventListener('change', function(){
    rule_HoeheGrundplatte();
    rule_GrundplatteHoeheBelag();
    showZubehoer();
    setDefaultZubehoer();
    showFarbe();
    alwaysExecute();
});

// Kabel
select_kabel.addEventListener('change', function(){
    showKabelProps();
    alwaysExecute();
})

btn_pro.addEventListener('change', function(){
    alwaysExecute();
});

// Kabelausgang
btn_kabelausgang_kurz.addEventListener('change', function(){
    showKabelProps();
    alwaysExecute();
});
btn_kabelausgang_lang.addEventListener('change', function(){
    showKabelProps();
    alwaysExecute();
});
btn_kabelausgang_dia.addEventListener('change', function(){
    showKabelProps();
    alwaysExecute();
});

// Invertierung
btn_invertiert.addEventListener('change', function(){
    alwaysExecute();
});

select_kabelpos.addEventListener('change', function(){
    alwaysExecute();
});

// Farbe
btn_frb_schwarz.addEventListener('change', function(){
    alwaysExecute();
});
btn_frb_grau.addEventListener('change', function(){
    alwaysExecute();
});
btn_frb_gelb.addEventListener('change', function(){
    alwaysExecute();
});

// Zubehoer
btn_zubehoer.addEventListener('change', function(){
    alwaysExecute();
});

// Befestigungshuelsen
btn_bhuelsen.addEventListener('change', function(){
    alwaysExecute();
});


// Sonstiges
function removeAll(selectElement) {
    let i, L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
       selectElement.remove(i);
    }
 }