$(document).ready(function () {
    let yOff = 300;
    let xOff = 10;

    // Oben links
    $(".text-hover-image-OL").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageOL + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-OL").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Oben Mitte 1
    $(".text-hover-image-OM-1").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageOM1 + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-OM-1").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Oben Mitte 2
    $(".text-hover-image-OM-2").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageOM2 + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-OM-2").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Oben Rechts
    $(".text-hover-image-OR").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageOR + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-OR").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Rechts Mitte 1
    $(".text-hover-image-RM-1").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageRM1 + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-RM-1").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Rechts Mitte 2
    $(".text-hover-image-RM-2").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageRM2 + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-RM-2").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Rechts unten
    $(".text-hover-image-RU").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageRU + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-RU").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });

    // Links unten
    $(".text-hover-image-LU").hover(function (e) {
        $("body").append("<p id='image-when-hovering-text' class='z-3'><img width='437.5px' height='328.75px' src='" + pathToImageLU + "'/></p>");
        $("#image-when-hovering-text")
            .css("position", "absolute")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px")
            .fadeIn("fast");
    },

    function () {
        $("#image-when-hovering-text").remove();
    });

    $(".text-hover-image-LU").mousemove(function (e) {
        $("#image-when-hovering-text")
            .css("top", (e.pageY - yOff) + "px")
            .css("left", (e.pageX + xOff) + "px");
    });
});