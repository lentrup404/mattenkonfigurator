// Mehrpreise
let mp_farbe = 82.29;
let mp_bhuelsen = 124.20;
let mp_kabelausgang = 137.09;
let mp_uebergroesse = 420.43;
let mp_pro = 124.43;
let mp_eckverbinder = 28.49;

// Zuschnitt / Material Rampenschiene
let zuschnitt = 35.87;
let materialpreis_rs = 30.384;

// Preise Kabelsets
let kabel_44 = 29.54;
let kabel_43 = 25.54;
let kabel_42 = 20.57;
let kabel_74 = 32.71;
let kabel_73 = 25.09;
let kabel_72 = 23.74;

// Grundpreise 
//Noppe/Sand
// 14-U-NP
// 14-U-SA
// 14-T-NP
// 14-T-SA
// 12-U-SA
// 12-T-SA
let grundpreis_1 = 353.43;
let pro_qm_1 = 655.16;

// ARB / TBV
// 14-F-ARB
// 14-F-TBV
let grundpreis_2 = 395.63;
let pro_qm_ARB = 710.02;
let pro_qm_TBV = 2227.11;

// Ohne Belag
let grundpreis_3 = 332.33;
let pro_qm_3 = 655.16;
 
function preisberechnung(){
    let belag = getBelag();
    let zubehoer = document.getElementById('zubehoer').checked;
    let befestigungshuelsen = document.getElementById('bhuelsen').checked;
    let kabel = document.getElementById('kabel').value;
    let pro = document.getElementById('pro').checked;
    let kabelposition = document.getElementById('kabelposition').value;
    let farbe = getFarbe();
    let laenge = document.getElementById("laenge").value;
    let breite = document.getElementById("breite").value;
    let qm = getQM();

    let ergebnis = 0.0;
    let grundpreis = 0.0;
    let preis_pro_qm = 0.0;

    if(belag == "NP" || belag == "SA"){
        grundpreis = grundpreis_1;
        preis_pro_qm = pro_qm_1;
    }
    else if(belag == "ARB" || belag == "TBV"){
        grundpreis = grundpreis_2;

        if(belag == "ARB"){
            preis_pro_qm = pro_qm_ARB;
        }
        else if(belag == "TBV"){
            preis_pro_qm = pro_qm_TBV;
        }
    }
    else if(belag == "OHNE"){
        grundpreis = grundpreis_3;
        preis_pro_qm = pro_qm_3;
    }

    document.getElementById('Grundpreis').value = grundpreis;
    document.getElementById("PreisProQM").value = preis_pro_qm;
    ergebnis = grundpreis + (preis_pro_qm * qm);

    // Mehrpreis Eckverbinder & Alurampenschiene
    if(zubehoer && laenge != 0 && breite != 0){
        ergebnis += mp_eckverbinder;

        let umfang_material = (((laenge-40)/1000)*2) + (((breite-40)/1000)*2);
        ergebnis += (materialpreis_rs * umfang_material) + zuschnitt;
    }

    // Mehrpreis Farbe
    if(farbe == "Gelb" || farbe == "Grau"){
        ergebnis += mp_farbe;
    }

    // Mehrpreis Befestigungshuelsen
    if(befestigungshuelsen){
        ergebnis += mp_bhuelsen;
    }

    // Mehrpreis PRO
    if(pro){
        ergebnis += mp_pro;
    }

    // Mehrpreis Übergröße
    if(laenge >= 2000 && breite > 1250){
        ergebnis += mp_uebergroesse;
    }

    // Mehrpreis Sonderkabelausgang
    if(kabelposition != "Ecke"){
        ergebnis += mp_kabelausgang;
    }

    // Preise für Kabelsets
    switch(kabel){
        case "4.2":
            ergebnis += kabel_42;
            break;
        case "4.3":
            ergebnis += kabel_43;
            break;
        case "4.4":
            ergebnis += kabel_44;
            break;
        case "7.2":
            ergebnis += kabel_72;
            break;
        case "7.3":
            ergebnis += kabel_73;
            break;
        case "7.4":
            ergebnis += kabel_74;
            break;
    }

    document.getElementById('preis').innerHTML = parseFloat(ergebnis).toFixed(2) + " €";
    document.getElementById('preis_value').value = ergebnis.toFixed(2); 
}

function getQM(){
    let breite = document.getElementById('breite').value;
    let laenge = document.getElementById('laenge').value;

    let qm = ((laenge/1000) * (breite/1000));

    return qm;
}