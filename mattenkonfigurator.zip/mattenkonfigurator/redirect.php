<?php
// Clear Session
session_start();
session_unset();

include('html/header.html');
include('html/navbar.html');
include('html/redirect.html');
include('html/footer.html');
?>