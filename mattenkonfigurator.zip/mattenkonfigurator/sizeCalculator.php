<?php
include("html/header.html");
include("html/navbar.html");
include("html/sizeCalc.html");
include("html/footer.html");
?>  