<?php
session_start();
include("html/header.html");
include('html/navbar.html');
?>

<body class='bg-dark-subtle'>
<div class='row w-100'>
    <div class='col'>
    <table class='table table-danger w-50 m-3 shadow border border-2 border-danger border-opacity-25'>
        <tr> <td> <?php echo $_SESSION['Vorname']." ".$_SESSION['Name']; ?> <td> <?php echo $_SESSION['Firma']; ?> </td> </tr>
        <tr> <td> <?php echo $_SESSION['Mail']; ?> <td> <?php echo $_SESSION['Telefon']; ?> </td> </tr>
    </table>
    </div>
    <div class='col'>
    <table class='table table-info w-50 m-3 shadow align-middle text-center border border-2 border-info border-opacity-25'>
        <tr height="82px"> <td rowspan=2>Hinweis: Lieferzeit ca. 4 Wochen </td> </tr>
    </table>
    </div>
</div>

<div class='row w-100 bg-secondary m-auto bg-gradient shadow'>
<div class='table-responsive col-md-6 shadow-lg'>
    <table class='table caption-top table-secondary table-hover'>
        <h2 class='mt-2'>Zusammenfassung</h2>
        <thead>
            <tr> <th class='text-start'>Bezeichnung</th> <th>Auswahl</th> </tr>
        </thead>
        <tbody>
           <tr> <th>Aufbauhöhe</th> <td> <?php echo $_SESSION['Hoehe']; ?> mm </td> </tr>
           <tr> <th>Grundplatte</th> <td><?php echo $_SESSION['Grundplatte']; ?> </td> </tr>
           <tr> <th>Belag</th> <td> <?php echo $_SESSION['Belag']; ?> </td> </tr>
           <tr> <th>Zubehör</th> <td> <?php echo ($_SESSION['Zubehoer'] == "1") ? "Ja" : "Nein" ?> </td> </tr>
           <tr> <th>Länge</th> <td> <?php echo $_SESSION['Laenge']; ?> mm</td> </tr>
           <tr> <th>Breite</th> <td> <?php echo $_SESSION['Breite']; ?> mm</td> </tr>
           <tr> <th>Befestigungshülsen</th> <td> <?php echo ($_SESSION['Befestigungshuelsen'] == "1") ? "Ja" : "Nein" ?> </td> </tr>
           <tr> <th>Kabeltyp</th> <td> <?php echo $_SESSION['Kabeltyp']; ?> </td> </tr>
           <tr> <th>Kabelausgang</th> <td> <?php echo $_SESSION['Kabelausgang']; ?> </td> </tr>
           <tr> <th>Kabelposition</th> <td> <?php echo $_SESSION['Kabelposition']; ?> </td> </tr>
           <tr> <th>Kabel invertieren</th> <td><?php echo ($_SESSION['invertiert'] == "1") ? "Ja" : "Nein" ?> </td> </tr>
           <tr> <th>PRO</th> <td> <?php echo ($_SESSION['Pro'] == "1") ? "Ja" : "Nein" ?> </td> </tr>
           <tr> <th>Farbe</th> <td> <?php echo (!isset($_SESSION['Farbe'])) ? "-" : $_SESSION['Farbe']; ?> </td> </tr>
        </tbody>
    </table>
</div>
<div class='table-responsive col-md-6 shadow-lg'>
    <table class='table table-secondary table-hover'>
        <h2 class='mt-2'>Preisberechnung</h2>
        <thead>
            <tr> <th class='text-start'>Service</th> <th class='text-end'>Preis</th> </tr>
        </thead>
        <tbody>
            <?php
            $materialpreisRS14 = 30.384;
            $zuschnittRS14 = 35.87;
            $eckverbinderRS14 = 28.49;
            $mp_bhuelsen = 124.20;
            $mp_kabelausgang = 137.09;
            $mp_pro = 124.43;
            $mp_farbe = 82.29;
            $mp_uebergroesse = 420.43;

            $summe = 0;
            $summe += $_SESSION['Grundpreis'];
            $summe += $_SESSION['PreisProQM'] * ($_SESSION['Laenge']/1000) * ($_SESSION['Breite']/1000);

            $kabel_preisrelevant = array("4.2", "4.3", "4.4", "7.2", "7.3", "7.4");
            echo "<tr> <th>Grundpreis</th> <td class='text-end'>".number_format($_SESSION['Grundpreis'], 2, ',', '.')." €</td> </tr>";
            echo "<tr> <th>Preis pro Quadratmeter</th> <td class='text-end'>".number_format($_SESSION['PreisProQM'], 2, ',', '.')." € * ".number_format(($_SESSION['Laenge']/1000 * $_SESSION['Breite']/1000), 2, ',', '.')."m<sup>2</sup> = ".number_format(($_SESSION['PreisProQM'] * ($_SESSION['Laenge']/1000) * ($_SESSION['Breite']/1000)), 2, ',', '.')." €</td> </tr>";
            if($_SESSION['Zubehoer'] == "1"){
                $umfang_berechnet = (((floatval($_SESSION['Laenge'])-40)/1000)*2) + (((floatval($_SESSION['Breite'])-40)/1000)*2);
                echo "<tr> <th> Materialpreis Rampenschiene (Zubehör) </th> <td class='text-end'>".number_format(($materialpreisRS14 * $umfang_berechnet), 2, ',', '.')." €</td> </tr>";
                echo "<tr> <th> Zuschnitt Rampenschiene (Zubehör) </th> <td class='text-end'>".number_format($zuschnittRS14, 2, ',', '.')." €</td> </tr>";
                echo "<tr> <th> Eckverbinder (Zubehör) </th> <td class='text-end'>".number_format($eckverbinderRS14, 2, ',', '.')." €</td> </tr>";

                $summe += $zuschnittRS14 + $eckverbinderRS14 + ($materialpreisRS14 * $umfang_berechnet);
            }

            if(in_array($_SESSION['Kabeltyp'], $kabel_preisrelevant)){
                switch($_SESSION['Kabeltyp']){
                    case "4.2":
                        $kabelpreis = 20.57;
                        break;
                    case "4.3":
                        $kabelpreis = 25.54;
                        break;
                    case "4.4":
                        $kabelpreis = 29.54;
                        break;
                    case "7.2":
                        $kabelpreis = 23.74;
                        break;
                    case "7.3":
                        $kabelpreis = 25.09;
                        break;
                    case "7.4":
                        $kabelpreis = 32.71;
                        break;
                }
                echo "<tr> <th> Kabelset (".$_SESSION['Kabeltyp'].") </th> <td class='text-end'>".number_format($kabelpreis, 2, ',', '.')." €</td> </tr>";
                $summe += $kabelpreis;
            }

            if($_SESSION['Befestigungshuelsen'] == "1"){
                echo "<tr> <th> Mehrpreis Befestigungshülsen </th> <td class='text-end'>".number_format($mp_bhuelsen, 2, ',', '.')." €</td> </tr>";
                $summe += $mp_bhuelsen;
            }

            if($_SESSION['Kabelausgang'] != "Ecke"){
                echo "<tr> <th> Mehrpreis Sonderkabelausgang </th> <td class='text-end'>".number_format($mp_kabelausgang, 2, ',', '.')." €</td> </tr>";
                $summe += $mp_kabelausgang;
            }

            if($_SESSION['Pro'] == "1"){
                echo "<tr> <th> Mehrpreis PRO </th> <td class='text-end'>".number_format($mp_pro, 2, ',', '.')." €</td> </tr>";
                $summe += $mp_pro;
            }

            if(isset($_SESSION['Farbe']) && $_SESSION['Farbe'] != "Schwarz"){
                echo "<tr> <th> Mehrpreis Farbe </th> <td class='text-end'>".number_format($mp_farbe, 2, ',', '.')." €</td> </tr>";
                $summe += $mp_farbe;
            }

            if($_SESSION['Laenge'] >= 2000 && $_SESSION['Breite'] > 1250){
                echo "<tr> <th> Mehrpreis Übergröße </th> <td class='text-end'>".number_format($mp_uebergroesse, 2, ',', '.')." €</td> </tr>";
                $summe += $mp_uebergroesse;
            }

            echo "<tr> <th> Summe </th> <td class='text-end'>".number_format($summe, 2, ',', '.')." € </td> </tr>";
            ?>
        </tbody>
    </table>
    <form action="db/dbinsert.php" method="post" class="needs-validation" novalidate>
        <div class='input-group mb-2 h-50' style='width:28%;'>
            <label for='menge' class='input-group-text'>Menge</label>
            <input class='form-control w-25' type="number" name="menge" id="menge" min=1 max=9999 required />
            <div class='px-1 invalid-feedback'>
                Bitte geben Sie eine valide Menge ein.
            </div>
        </div>    
        <div class='form-floating w-75'>
            <textarea class='form-control mb-2' name="kommentar" id="kommentar" style='height: 110px;resize: none;'></textarea>
            <label class='ms-2' for='kommentar'>Weitere Anmerkungen</label>
        </div>
        <button type='button' class='btn btn-danger mb-2' onclick='history.back()' style='width: 25%;'>Zurück</button>
        <button class='btn btn-danger mb-2' type='submit' style='width: 74%;' >Angebot bestätigen</button>
    </form>
</div>
</div>
</body>

<script src="js/validation.js"></script>
<?php
include("html/footer.html");
?>