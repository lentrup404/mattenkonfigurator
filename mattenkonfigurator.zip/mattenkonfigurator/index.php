<?php
include('html/header.html');
include('html/navbar.html');
include("html/index.html");
include('html/footer.html');
?>