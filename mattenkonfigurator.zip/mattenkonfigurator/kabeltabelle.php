<?php
include('html/header.html');
include('html/navbar.html');
include("html/kabeltabelle.html");
include('html/footer.html');
?>


