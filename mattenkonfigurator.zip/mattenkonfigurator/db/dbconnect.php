<?php
date_default_timezone_set('Europe/Berlin');
$serverName = "ERP-SERVER";
// Zugangsdaten wurden unkenntlich gemacht
$connectionInfo = array( "Database"=>"***", "UID"=>"***", "PWD"=>"***"); 

$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     
}else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}
?>