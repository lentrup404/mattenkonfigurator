<?php
session_start();
include("dbconnect.php");

$sql = "Insert into _mattenkonfigurator 
(Name, Vorname, Mail, Firma, Telefon, Hoehe, Grundplatte, Belag, Zubehoer, Befestigungshuelsen, Laenge, Breite, Kabeltyp, Kabelausgang, Kabelposition, invertieren, Pro, Farbe, Preis, Menge, Anmerkung) 
values
(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
 
$params = array($_SESSION['Name'], $_SESSION['Vorname'], $_SESSION['Mail'], $_SESSION['Firma'], $_SESSION['Telefon'], $_SESSION['Hoehe'], $_SESSION['Grundplatte'], 
$_SESSION['Belag'], $_SESSION['Zubehoer'], $_SESSION['Befestigungshuelsen'], $_SESSION['Laenge'], $_SESSION['Breite'], $_SESSION['Kabeltyp'], $_SESSION['Kabelausgang'], 
$_SESSION['Kabelposition'], $_SESSION['invertiert'], $_SESSION['Pro'], $_SESSION['Farbe'], $_SESSION['Preis'], $_POST['menge'], $_POST['kommentar']);

$result = sqlsrv_query($conn, $sql, $params);

if($result === false){
    die(print_r(sqlsrv_errors(), true));
}
else{
    header("Location: ../redirect.php");
}
?>