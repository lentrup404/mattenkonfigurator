<?php
    session_start();

    $_SESSION['Name'] = $_POST['Name'];
    $_SESSION['Vorname'] = $_POST['Vorname'];
    $_SESSION['Firma'] = $_POST['Firma'];
    $_SESSION['Mail'] = $_POST['email'];
    $_SESSION['Telefon'] = $_POST['Telefon'];

    header('Location: main.php');
?>